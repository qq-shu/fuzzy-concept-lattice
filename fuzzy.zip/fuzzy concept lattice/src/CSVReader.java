import model.FormalContext;
import model.RuleTable;
import model.Transaction;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CSVReader {
    public CSVReader(FormalContext context, String FilePath) throws IOException {
        /*CSV和EXCEL转的过程中，可能出现空的一行，使CSV文件读取出错。*/
        FileReader fileread = new FileReader(new File(FilePath));
        BufferedReader buffread = new BufferedReader(fileread);
        String line;

        //得到模糊形式背景的属性集
        if((line = buffread.readLine()) == null){
            System.out.println("空文件");
            buffread.close();
            return;
        }
        String[] s = line.split(",",2);
        String[] m = s[1].split(","); //默认第一列为序号
        context.setM(Arrays.asList(m));

        //得到模糊形式背景的一组均值隶属度集
        if((line = buffread.readLine()) == null){
            System.out.println("请输入平均隶属度");
            buffread.close();
            return;
        }
        String[] av = line.split(","); //一组平均隶属度
        List<Double> AV = new ArrayList<>();//存储均值隶属度
        for (int i = 1; i < av.length; i++) {
            AV.add(Double.valueOf(av[i]));
        }
        context.setAV(AV);



        int Tid = 0;
        //提取事务的属性集
        while ((line = buffread.readLine()) != null) {
            Transaction tr = new Transaction(); //建立一条事务
            String[] attr = line.split(","); //存储的一条事务
            List<Double> value = new ArrayList<>();//存储属性值
            List<String> attrName = new ArrayList<>();//存储属性值

            tr.setTid(Tid);
            tr.setName(attr[0]);

            int i;
            for (i = 1; i < attr.length-1; i++) {
                if (Double.valueOf(attr[i])>AV.get(i-1)) {
                    attrName.add(m[i-1]);
                    value.add(Double.valueOf(attr[i]));
                }
                else value.add(0.0);
            }

            tr.setAttritudes(attrName);
            tr.setValue(value);
            tr.setOutput(Double.valueOf(attr[i]));

            Tid++;
            context.setTr(tr);
        }
        buffread.close();
    }
}


