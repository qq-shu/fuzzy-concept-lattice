package model;

import java.util.List;

public class RuleTable {

    private List<String> name;
}
