package model;

import java.util.LinkedList;
import java.util.List;

public class Rule {
    List<String> primise ;
    List<String> conclusion;
    double support ;//支持度
    double confidence;//置信度
    double lift;//提升度
    double output;//输出值
    double variance;//偏离度

    public Rule(){
        primise = new LinkedList<>();
        conclusion = new LinkedList<>();
    }

    public List<String> getPrimise() {
        return primise;
    }

    public void setPrimise(List<String> primise) {
        this.primise = primise;
    }

    public void set_aPrimise(String primise) {
        this.primise.add(primise);
    }

    public List<String> getConclusion() {
        return conclusion;
    }

    public void setConclusion(List<String> conclusion) {
        this.conclusion = conclusion;
    }

    public double getSupport() {
        return support;
    }

    public void setSupport(double support) {
        this.support = support;
    }

    public double getConfidence() {
        return confidence;
    }

    public void setConfidence(double confidence) {
        this.confidence = confidence;
    }

    public double getLift() {
        return lift;
    }

    public void setLift(double lift) {
        this.lift = lift;
    }

    public double getOutput() {
        return output;
    }

    public void setOutput(double output) {
        this.output = output;
    }

    public double getVariance() {
        return variance;
    }

    public void setVariance(double variance) {
        this.variance = variance;
    }

    public String toString(){
        return primise.toString()+"===>"+conclusion.toString()+", Con："+confidence+", Lift："+lift+", output:"+output+", var:"+variance;
    }

    public void Print(){
        System.out.println(this.toString());
    }

}
